# wakelock_example

Example app demonstrating how to use the wakelock plugin. It also includes integration tests for
testing the plugin in an integrated example.

## Integration tests

You can run the integration tests using the following command:

```
flutter drive --driver=test_driver/integration_test.dart --target=integration_test/wakelock_test.dart
```
