Please see the release notes page for the full change log
https://github.com/OneSignal/OneSignal-Flutter-SDK/releases