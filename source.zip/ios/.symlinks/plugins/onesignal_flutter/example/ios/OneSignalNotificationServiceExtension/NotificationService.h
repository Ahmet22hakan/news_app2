//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by Brad Hesse on 7/13/18.
//  Copyright © 2018 The Chromium Authors. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
