#import "SqfliteCursor.h"
#import "SqfliteFmdbImport.m"

@implementation SqfliteCursor

@synthesize cursorId;
@synthesize pageSize;
@synthesize resultSet;

@end
