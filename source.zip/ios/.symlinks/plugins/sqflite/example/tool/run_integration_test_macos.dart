import 'run_integration_test.dart';

Future<void> main(List<String> arguments) async {
  await runIntegrationTest(deviceId: 'macos');
}
