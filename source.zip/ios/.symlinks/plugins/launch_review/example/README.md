# launch_review_example

Demonstrates how to use the launch_review plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
