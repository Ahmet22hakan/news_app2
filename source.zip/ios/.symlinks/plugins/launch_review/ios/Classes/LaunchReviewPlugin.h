#import <Flutter/Flutter.h>

@interface LaunchReviewPlugin : NSObject<FlutterPlugin>
@end
