## 3.0.1

* Fixing pubspec issue

## 3.0.0

* Null safety support. Thanks to @fzyzcjy for the PR.
* Supports v2 embeddings. Thanks to Leonardo da Silva for the PR.

## 2.0.0

* Migrate to AndroidX.
* Fix iOS crash. Thanks to @KaYBlitZ for the PR.
* Adds check for canOpenURL on iOS. Thanks to @hugey010 for the PR.

## 1.0.1

* Add iOS support

## 0.2.0

* Make the package Id optional.

## 0.1.0

* Initial Open Source release for Android.