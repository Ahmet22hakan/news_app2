import 'package:flutter/material.dart';

class LoveCount extends StatelessWidget {
  final String collectionName;
  final String? timestamp;
  const LoveCount({Key? key, required this.collectionName, required this.timestamp}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
     }
}
