class Comment {
  String? uid;
  String? name;
  String? imageUrl;
  String? comment;
  String? date;
  String? timestamp;

  Comment({this.uid, this.name, this.imageUrl, this.comment, this.date, this.timestamp});

}
