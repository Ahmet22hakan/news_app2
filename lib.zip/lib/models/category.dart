

class CategoryModel {
  String? name;
  String? thumbnailUrl;
  String? timestamp;

  CategoryModel({
    this.name,
    this.thumbnailUrl,
    this.timestamp
  });


 
}