class Constants {
  static final String fcmSubscriptionTopic = 'all';
  static final notificationTag = 'notifications';
}