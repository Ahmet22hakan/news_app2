class HiveService{

  HiveService hiveService = HiveService();

  closeBoxes (){
    hiveService.closeBoxes();
  }

}